package com.prepiq.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.Max;
import jakarta.validation.constraints.Min;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "attempts")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class Attempt {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "question_id", nullable = false)
    private Question question;

    @Column(nullable = false, columnDefinition = "TEXT")
    private String userAnswer;

    // Overall score 0–100 (set after NLP analysis)
    @Min(0) @Max(100)
    @Builder.Default
    private Integer score = 0;

    @CreationTimestamp
    @Column(updatable = false)
    private LocalDateTime attemptedAt;

    // One attempt produces one feedback record
    @OneToOne(mappedBy = "attempt", cascade = CascadeType.ALL, fetch = FetchType.LAZY)
    private Feedback feedback;
}
