package com.prepiq.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "feedback")
@Getter @Setter
@NoArgsConstructor @AllArgsConstructor
@Builder
public class Feedback {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "attempt_id", nullable = false)
    private Attempt attempt;

    // Scores from Python NLP service (0-100)
    private Integer keywordScore;
    private Integer sentimentScore;
    private Integer lengthScore;
    private Integer technicalScore;

    // Comma-separated missing keywords
    @Column(columnDefinition = "TEXT")
    private String missingKeywords;

    // Improvement suggestions from NLP
    @Column(columnDefinition = "TEXT")
    private String suggestions;
}
