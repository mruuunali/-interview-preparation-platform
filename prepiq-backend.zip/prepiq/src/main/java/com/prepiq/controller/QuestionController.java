package com.prepiq.controller;

import com.prepiq.dto.request.CreateQuestionRequest;
import com.prepiq.dto.response.ApiResponse;
import com.prepiq.dto.response.QuestionResponse;
import com.prepiq.service.QuestionService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/questions")
@RequiredArgsConstructor
public class QuestionController {

    private final QuestionService questionService;

    // GET /api/questions?category=JAVA&difficulty=MEDIUM
    @GetMapping
    public ResponseEntity<List<QuestionResponse>> getAll(
            @RequestParam(required = false) String category,
            @RequestParam(required = false) String difficulty) {
        return ResponseEntity.ok(questionService.getAll(category, difficulty));
    }

    @GetMapping("/{id}")
    public ResponseEntity<QuestionResponse> getById(@PathVariable Long id) {
        return ResponseEntity.ok(questionService.getById(id));
    }

    // Admin only
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<QuestionResponse> create(@Valid @RequestBody CreateQuestionRequest req) {
        return ResponseEntity.ok(questionService.create(req));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse> delete(@PathVariable Long id) {
        questionService.delete(id);
        return ResponseEntity.ok(new ApiResponse(true, "Question deleted"));
    }
}
