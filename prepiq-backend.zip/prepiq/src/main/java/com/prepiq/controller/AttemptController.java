package com.prepiq.controller;

import com.prepiq.dto.request.SubmitAnswerRequest;
import com.prepiq.dto.response.*;
import com.prepiq.service.AttemptService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api")
@RequiredArgsConstructor
public class AttemptController {

    private final AttemptService attemptService;

    @PostMapping("/attempts")
    public ResponseEntity<FeedbackResponse> submit(
            @AuthenticationPrincipal UserDetails userDetails,
            @Valid @RequestBody SubmitAnswerRequest req) {
        return ResponseEntity.ok(attemptService.submitAnswer(userDetails.getUsername(), req));
    }

    @GetMapping("/attempts/history")
    public ResponseEntity<List<AttemptResponse>> history(
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(attemptService.getHistory(userDetails.getUsername()));
    }

    @GetMapping("/dashboard/stats")
    public ResponseEntity<DashboardResponse> dashboard(
            @AuthenticationPrincipal UserDetails userDetails) {
        return ResponseEntity.ok(attemptService.getDashboard(userDetails.getUsername()));
    }
}
