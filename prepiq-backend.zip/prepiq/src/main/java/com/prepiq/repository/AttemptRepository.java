package com.prepiq.repository;

import com.prepiq.entity.Attempt;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AttemptRepository extends JpaRepository<Attempt, Long> {
    List<Attempt> findByUserIdOrderByAttemptedAtDesc(Long userId);
    List<Attempt> findByUserIdAndQuestionId(Long userId, Long questionId);

    @Query("SELECT AVG(a.score) FROM Attempt a WHERE a.user.id = :userId")
    Double findAverageScoreByUserId(Long userId);

    @Query("SELECT COUNT(a) FROM Attempt a WHERE a.user.id = :userId")
    Long countByUserId(Long userId);
}
