package com.prepiq.repository;

import com.prepiq.entity.Question;
import com.prepiq.enums.Category;
import com.prepiq.enums.Difficulty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface QuestionRepository extends JpaRepository<Question, Long> {
    List<Question> findByCategory(Category category);
    List<Question> findByDifficulty(Difficulty difficulty);
    List<Question> findByCategoryAndDifficulty(Category category, Difficulty difficulty);
}
