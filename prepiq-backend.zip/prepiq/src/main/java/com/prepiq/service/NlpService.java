package com.prepiq.service;

import com.prepiq.dto.response.FeedbackResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.*;

/**
 * Calls the Python Flask NLP microservice.
 * Falls back to basic local scoring if NLP service is unavailable.
 */
@Service
@RequiredArgsConstructor
public class NlpService {

    private final RestTemplate restTemplate;
    private static final String NLP_URL = "http://localhost:5000/analyze";

    public FeedbackResponse analyze(String answer, String keywordsStr) {
        try {
            Map<String, String> body = new HashMap<>();
            body.put("answer", answer);
            body.put("keywords", keywordsStr != null ? keywordsStr : "");

            @SuppressWarnings("unchecked")
            Map<String, Object> result = restTemplate.postForObject(NLP_URL, body, Map.class);

            if (result != null) {
                return buildFromNlpResult(result);
            }
        } catch (Exception e) {
            // NLP service not running — use local fallback
        }
        return localFallback(answer, keywordsStr);
    }

    @SuppressWarnings("unchecked")
    private FeedbackResponse buildFromNlpResult(Map<String, Object> result) {
        return FeedbackResponse.builder()
                .overallScore((Integer) result.get("overall_score"))
                .keywordScore((Integer) result.get("keyword_score"))
                .sentimentScore((Integer) result.get("sentiment_score"))
                .lengthScore((Integer) result.get("length_score"))
                .technicalScore((Integer) result.get("technical_score"))
                .missingKeywords((List<String>) result.get("missing_keywords"))
                .suggestions((String) result.get("suggestions"))
                .build();
    }

    // Simple fallback scoring when Python service is offline
    private FeedbackResponse localFallback(String answer, String keywordsStr) {
        int wordCount = answer.trim().split("\\s+").length;

        // Length score
        int lengthScore = wordCount < 30 ? 30 : wordCount > 300 ? 90 : (int)(wordCount / 300.0 * 90);

        // Keyword score
        List<String> missing = new ArrayList<>();
        int keywordScore = 50;
        if (keywordsStr != null && !keywordsStr.isBlank()) {
            String[] keywords = keywordsStr.split(",");
            long hits = Arrays.stream(keywords)
                    .filter(kw -> answer.toLowerCase().contains(kw.trim().toLowerCase()))
                    .count();
            for (String kw : keywords) {
                if (!answer.toLowerCase().contains(kw.trim().toLowerCase())) missing.add(kw.trim());
            }
            keywordScore = (int)((double) hits / keywords.length * 100);
        }

        int overall = (keywordScore + lengthScore + 60) / 3;

        return FeedbackResponse.builder()
                .overallScore(overall)
                .keywordScore(keywordScore)
                .sentimentScore(60)
                .lengthScore(lengthScore)
                .technicalScore(50)
                .missingKeywords(missing)
                .suggestions("Try to include more technical keywords and concrete examples in your answer.")
                .build();
    }
}
