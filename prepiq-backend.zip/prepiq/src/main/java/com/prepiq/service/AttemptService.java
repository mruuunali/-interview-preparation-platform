package com.prepiq.service;

import com.prepiq.dto.request.SubmitAnswerRequest;
import com.prepiq.dto.response.AttemptResponse;
import com.prepiq.dto.response.DashboardResponse;
import com.prepiq.dto.response.FeedbackResponse;
import com.prepiq.entity.*;
import com.prepiq.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AttemptService {

    private final AttemptRepository attemptRepository;
    private final QuestionRepository questionRepository;
    private final UserRepository userRepository;
    private final FeedbackRepository feedbackRepository;
    private final NlpService nlpService;

    public FeedbackResponse submitAnswer(String userEmail, SubmitAnswerRequest req) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Question question = questionRepository.findById(req.getQuestionId())
                .orElseThrow(() -> new RuntimeException("Question not found"));

        // Call Python NLP service
        FeedbackResponse nlpResult = nlpService.analyze(req.getAnswer(), question.getKeywords());

        // Save attempt
        Attempt attempt = Attempt.builder()
                .user(user)
                .question(question)
                .userAnswer(req.getAnswer())
                .score(nlpResult.getOverallScore())
                .build();
        attempt = attemptRepository.save(attempt);

        // Save feedback
        Feedback feedback = Feedback.builder()
                .attempt(attempt)
                .keywordScore(nlpResult.getKeywordScore())
                .sentimentScore(nlpResult.getSentimentScore())
                .lengthScore(nlpResult.getLengthScore())
                .technicalScore(nlpResult.getTechnicalScore())
                .missingKeywords(String.join(",", nlpResult.getMissingKeywords()))
                .suggestions(nlpResult.getSuggestions())
                .build();
        feedbackRepository.save(feedback);

        nlpResult.setAttemptId(attempt.getId());
        nlpResult.setModelAnswer(question.getModelAnswer());
        return nlpResult;
    }

    public List<AttemptResponse> getHistory(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
        return attemptRepository.findByUserIdOrderByAttemptedAtDesc(user.getId())
                .stream().map(this::toResponse).collect(Collectors.toList());
    }

    public DashboardResponse getDashboard(String userEmail) {
        User user = userRepository.findByEmail(userEmail)
                .orElseThrow(() -> new RuntimeException("User not found"));
        Long total = attemptRepository.countByUserId(user.getId());
        Double avg   = attemptRepository.findAverageScoreByUserId(user.getId());
        List<AttemptResponse> recent = attemptRepository
                .findByUserIdOrderByAttemptedAtDesc(user.getId())
                .stream().limit(5).map(this::toResponse).collect(Collectors.toList());
        return DashboardResponse.builder()
                .totalAttempts(total)
                .averageScore(avg != null ? Math.round(avg * 10.0) / 10.0 : 0.0)
                .scoreByCategory(new HashMap<>())
                .recentAttempts(recent)
                .build();
    }

    private AttemptResponse toResponse(Attempt a) {
        return AttemptResponse.builder()
                .id(a.getId())
                .questionId(a.getQuestion().getId())
                .questionText(a.getQuestion().getQuestionText())
                .category(a.getQuestion().getCategory().name())
                .score(a.getScore())
                .attemptedAt(a.getAttemptedAt())
                .build();
    }
}
