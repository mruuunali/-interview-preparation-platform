package com.prepiq.service;

import com.prepiq.dto.request.CreateQuestionRequest;
import com.prepiq.dto.response.QuestionResponse;
import com.prepiq.entity.Question;
import com.prepiq.enums.Category;
import com.prepiq.enums.Difficulty;
import com.prepiq.repository.QuestionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class QuestionService {

    private final QuestionRepository questionRepository;

    public List<QuestionResponse> getAll(String category, String difficulty) {
        List<Question> questions;
        if (category != null && difficulty != null) {
            questions = questionRepository.findByCategoryAndDifficulty(
                    Category.valueOf(category.toUpperCase()),
                    Difficulty.valueOf(difficulty.toUpperCase()));
        } else if (category != null) {
            questions = questionRepository.findByCategory(Category.valueOf(category.toUpperCase()));
        } else if (difficulty != null) {
            questions = questionRepository.findByDifficulty(Difficulty.valueOf(difficulty.toUpperCase()));
        } else {
            questions = questionRepository.findAll();
        }
        return questions.stream().map(this::toResponse).collect(Collectors.toList());
    }

    public QuestionResponse getById(Long id) {
        Question q = questionRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Question not found"));
        return toResponse(q);
    }

    public QuestionResponse create(CreateQuestionRequest req) {
        Question q = Question.builder()
                .questionText(req.getQuestionText())
                .category(req.getCategory())
                .difficulty(req.getDifficulty())
                .modelAnswer(req.getModelAnswer())
                .keywords(req.getKeywords())
                .build();
        return toResponse(questionRepository.save(q));
    }

    public void delete(Long id) {
        questionRepository.deleteById(id);
    }

    private QuestionResponse toResponse(Question q) {
        return QuestionResponse.builder()
                .id(q.getId())
                .questionText(q.getQuestionText())
                .category(q.getCategory())
                .difficulty(q.getDifficulty())
                .build();
    }
}
