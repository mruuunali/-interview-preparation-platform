package com.prepiq.dto.response;
import lombok.*;

@Data @Builder @AllArgsConstructor
public class AuthResponse {
    private String token;
    private String name;
    private String email;
    private String role;
}
