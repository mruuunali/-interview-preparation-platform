package com.prepiq.dto.response;
import lombok.*;
import java.util.*;

@Data @Builder
public class DashboardResponse {
    private Long totalAttempts;
    private Double averageScore;
    private Map<String, Double> scoreByCategory;
    private List<AttemptResponse> recentAttempts;
}
