package com.prepiq.dto.response;
import lombok.*;
import java.util.List;

@Data @Builder
public class FeedbackResponse {
    private Long attemptId;
    private Integer overallScore;
    private Integer keywordScore;
    private Integer sentimentScore;
    private Integer lengthScore;
    private Integer technicalScore;
    private List<String> missingKeywords;
    private String suggestions;
    private String modelAnswer;
}
