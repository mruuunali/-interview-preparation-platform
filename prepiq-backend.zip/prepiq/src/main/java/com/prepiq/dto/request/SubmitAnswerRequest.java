package com.prepiq.dto.request;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class SubmitAnswerRequest {
    @NotNull(message = "Question ID is required")
    private Long questionId;
    @NotBlank(message = "Answer cannot be empty")
    private String answer;
}
