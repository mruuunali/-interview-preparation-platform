package com.prepiq.dto.response;
import lombok.*;
import java.time.LocalDateTime;

@Data @Builder
public class AttemptResponse {
    private Long id;
    private Long questionId;
    private String questionText;
    private String category;
    private Integer score;
    private LocalDateTime attemptedAt;
}
