package com.prepiq.dto.response;
import com.prepiq.enums.*;
import lombok.*;

@Data @Builder
public class QuestionResponse {
    private Long id;
    private String questionText;
    private Category category;
    private Difficulty difficulty;
}
