package com.prepiq.dto.request;
import com.prepiq.enums.*;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class CreateQuestionRequest {
    @NotBlank private String questionText;
    @NotNull  private Category category;
    @NotNull  private Difficulty difficulty;
    private String modelAnswer;
    private String keywords;
}
