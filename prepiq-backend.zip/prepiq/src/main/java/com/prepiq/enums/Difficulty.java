package com.prepiq.enums;
public enum Difficulty { EASY, MEDIUM, HARD }
