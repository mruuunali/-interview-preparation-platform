package com.prepiq.enums;
public enum Role { USER, ADMIN }
