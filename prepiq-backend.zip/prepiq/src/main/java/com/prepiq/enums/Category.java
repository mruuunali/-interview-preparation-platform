package com.prepiq.enums;
public enum Category { JAVA, SPRING, DSA, SYSTEM_DESIGN, HR }
