"""
app.py  —  Flask entry point.
Spring Boot hits POST /analyze with { "answer": "...", "keywords": "..." }
Returns JSON score breakdown.
Run:  python app.py
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
import scorer

app = Flask(__name__)
CORS(app)  # Allow requests from Spring Boot and the HTML frontend


# ── Health check — Spring Boot pings this on startup ─────────────────────────
@app.route("/health", methods=["GET"])
def health():
    return jsonify({"status": "ok", "service": "prepiq-nlp"}), 200


# ── Main scoring endpoint ─────────────────────────────────────────────────────
@app.route("/analyze", methods=["POST"])
def analyze():
    data = request.get_json()

    if not data:
        return jsonify({"error": "Request body must be JSON"}), 400

    answer      = data.get("answer", "").strip()
    keywords    = data.get("keywords", "").strip()

    if not answer:
        return jsonify({"error": "answer field is required"}), 400

    result = scorer.analyze(answer, keywords)
    return jsonify(result), 200


# ── Batch endpoint (optional — for future mock interview mode) ────────────────
@app.route("/analyze/batch", methods=["POST"])
def analyze_batch():
    data = request.get_json()
    if not data or "items" not in data:
        return jsonify({"error": "Expected { items: [{answer, keywords}] }"}), 400

    results = []
    for item in data["items"]:
        answer   = item.get("answer", "")
        keywords = item.get("keywords", "")
        results.append(scorer.analyze(answer, keywords))

    return jsonify({"results": results}), 200


if __name__ == "__main__":
    print("PrepIQ NLP service starting on http://localhost:5000")
    app.run(debug=True, port=5000)
