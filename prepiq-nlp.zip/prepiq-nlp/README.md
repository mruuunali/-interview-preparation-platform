# PrepIQ — NLP Feedback Service

Python Flask microservice that scores interview answers using spaCy and TextBlob.

## Setup (run once)

```bash
# 1. Create virtual environment
python -m venv venv

# 2. Activate it
# Windows:
venv\Scripts\activate
# Mac/Linux:
source venv/bin/activate

# 3. Install dependencies
pip install -r requirements.txt

# 4. Download spaCy language model
python -m spacy download en_core_web_sm

# 5. Download NLTK data (needed by TextBlob)
python -c "import nltk; nltk.download('punkt'); nltk.download('averaged_perceptron_tagger')"
```

## Run

```bash
python app.py
# Server starts at http://localhost:5000
```

## Test

```bash
python test_scorer.py
```

## API

### POST /analyze
```json
Request:
{
  "answer": "Your answer text here",
  "keywords": "keyword1,keyword2,keyword3"
}

Response:
{
  "overall_score": 74,
  "keyword_score": 65,
  "sentiment_score": 72,
  "length_score": 90,
  "technical_score": 68,
  "missing_keywords": ["keyword2"],
  "suggestions": "Include missing keywords: keyword2...",
  "word_count": 142
}
```

### GET /health
Returns `{ "status": "ok" }` — used by Spring Boot to check if service is up.

## Scoring Weights
| Component      | Weight |
|----------------|--------|
| Keyword match  | 40%    |
| Technical depth| 25%    |
| Answer length  | 20%    |
| Confidence tone| 15%    |
