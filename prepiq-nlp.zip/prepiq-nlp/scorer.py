"""
scorer.py  —  All NLP scoring logic lives here.
Spring Boot calls /analyze and gets back a JSON score breakdown.
"""

import re
import spacy
from textblob import TextBlob

# Load spaCy English model (small — fast enough for this use case)
try:
    nlp = spacy.load("en_core_web_sm")
except OSError:
    # If model not downloaded yet, we handle it gracefully
    nlp = None


# ── 1. KEYWORD SCORE ─────────────────────────────────────────────────────────
def score_keywords(answer: str, keywords_str: str) -> dict:
    """
    Check how many expected keywords appear in the answer.
    Returns score (0-100), list of hits, and list of missing keywords.
    """
    if not keywords_str or not keywords_str.strip():
        return {"score": 50, "hits": [], "missing": []}

    answer_lower = answer.lower()
    keywords = [kw.strip().lower() for kw in keywords_str.split(",") if kw.strip()]

    hits = []
    missing = []

    for kw in keywords:
        # Match whole word or phrase (flexible — allows partial class/annotation names)
        if kw in answer_lower:
            hits.append(kw)
        else:
            missing.append(kw)

    if not keywords:
        return {"score": 50, "hits": [], "missing": []}

    score = int((len(hits) / len(keywords)) * 100)
    return {"score": score, "hits": hits, "missing": missing}


# ── 2. SENTIMENT / CONFIDENCE SCORE ──────────────────────────────────────────
def score_sentiment(answer: str) -> int:
    """
    Uses TextBlob polarity + subjectivity to measure how confident
    and assertive the answer sounds.
    Positive, assertive answers score higher.
    Hedging language ('maybe', 'I think', 'not sure') reduces score.
    """
    blob = TextBlob(answer)
    polarity     = blob.sentiment.polarity      # -1 to 1
    subjectivity = blob.sentiment.subjectivity  # 0 (objective) to 1 (subjective)

    # Ideal: slightly positive, mostly objective (factual technical answer)
    base = 60

    # Boost for confident positive tone
    if polarity > 0.1:
        base += 15
    elif polarity < -0.2:
        base -= 10

    # Penalise overly subjective / uncertain answers
    if subjectivity > 0.6:
        base -= 10
    elif subjectivity < 0.3:
        base += 10

    # Penalise hedging language
    hedges = ["i think", "maybe", "i'm not sure", "not sure", "i guess",
              "probably", "i believe", "i feel like", "could be", "might be"]
    answer_lower = answer.lower()
    hedge_count = sum(1 for h in hedges if h in answer_lower)
    base -= hedge_count * 5

    return max(0, min(100, base))


# ── 3. LENGTH SCORE ───────────────────────────────────────────────────────────
def score_length(answer: str) -> dict:
    """
    Scores answer based on word count.
    Sweet spot: 80–350 words.
    Too short = incomplete. Too long = rambling.
    """
    words = len(answer.strip().split())

    if words < 20:
        score = 20
        note = "Too short — write at least 3-4 sentences."
    elif words < 50:
        score = 45
        note = "A bit brief — expand your explanation."
    elif words < 80:
        score = 65
        note = "Decent length — could add one more example."
    elif words <= 350:
        score = 90
        note = "Good length."
    elif words <= 500:
        score = 75
        note = "Slightly long — be more concise."
    else:
        score = 55
        note = "Too long — trim to the key points."

    return {"score": score, "word_count": words, "note": note}


# ── 4. TECHNICAL DEPTH SCORE ─────────────────────────────────────────────────
def score_technical_depth(answer: str) -> int:
    """
    Checks for technical indicators:
    - Code-like tokens (@Annotation, ClassName, methodName())
    - Technical verbs (implement, define, extend, override…)
    - Structured explanation patterns (first/then/finally, because, therefore)
    Uses spaCy NER + POS tagging if available, else regex fallback.
    """
    answer_lower = answer.lower()
    score = 40  # base

    # Annotations and class-name patterns (@Something, CamelCase)
    annotations = re.findall(r'@[A-Za-z]+', answer)
    camel_case   = re.findall(r'\b[A-Z][a-z]+[A-Z][a-zA-Z]+\b', answer)
    method_calls = re.findall(r'\b\w+\(\)', answer)
    score += min(len(annotations) * 8, 24)
    score += min(len(camel_case)   * 4, 16)
    score += min(len(method_calls) * 5, 15)

    # Technical verbs
    tech_verbs = ["implement", "instantiate", "override", "extend", "inherit",
                  "inject", "configure", "deploy", "serialize", "authenticate",
                  "authorize", "cache", "index", "query", "parse", "compile"]
    verb_hits = sum(1 for v in tech_verbs if v in answer_lower)
    score += min(verb_hits * 5, 20)

    # Structured explanation (shows the candidate can explain clearly)
    structure_words = ["because", "therefore", "which means", "this allows",
                       "for example", "such as", "in other words", "as a result"]
    structure_hits = sum(1 for s in structure_words if s in answer_lower)
    score += min(structure_hits * 4, 12)

    # spaCy-based boost: named entities that look technical
    if nlp:
        doc = nlp(answer[:1000])  # limit to 1000 chars for speed
        tech_entities = [ent for ent in doc.ents if ent.label_ in ("ORG", "PRODUCT", "GPE")]
        score += min(len(tech_entities) * 3, 9)

    return max(0, min(100, score))


# ── 5. SUGGESTIONS GENERATOR ─────────────────────────────────────────────────
def generate_suggestions(keyword_result: dict, length_result: dict,
                          sentiment_score: int, technical_score: int) -> str:
    """
    Produces 1-3 human-readable improvement tips based on the scores.
    """
    tips = []

    # Keyword tips
    missing = keyword_result.get("missing", [])
    if missing:
        shown = missing[:3]
        tip = f"Include these missing keywords: {', '.join(shown)}"
        if len(missing) > 3:
            tip += f" (and {len(missing)-3} more)"
        tip += ". These are terms interviewers specifically listen for."
        tips.append(tip)

    # Length tips
    if length_result["score"] < 65:
        tips.append(length_result["note"] + " Aim for 80–350 words.")

    # Confidence tips
    if sentiment_score < 55:
        tips.append("Use more assertive language. Avoid phrases like 'I think' or 'maybe' — state facts confidently.")

    # Technical depth tips
    if technical_score < 55:
        tips.append("Add more technical depth — mention specific class names, annotations, or a short code example.")

    if not tips:
        tips.append("Good answer! To make it excellent, add a real-world example or edge case.")

    return " | ".join(tips)


# ── 6. MASTER ANALYZE FUNCTION ───────────────────────────────────────────────
def analyze(answer: str, keywords_str: str) -> dict:
    """
    Entry point called by Flask route.
    Returns full scoring breakdown as a dict (serialised to JSON by Flask).
    """
    if not answer or not answer.strip():
        return {
            "overall_score": 0,
            "keyword_score": 0,
            "sentiment_score": 0,
            "length_score": 0,
            "technical_score": 0,
            "missing_keywords": [],
            "suggestions": "No answer provided.",
            "word_count": 0
        }

    keyword_result  = score_keywords(answer, keywords_str)
    sentiment_score = score_sentiment(answer)
    length_result   = score_length(answer)
    technical_score = score_technical_depth(answer)

    # Weighted overall score
    # Keywords matter most (40%), then technical depth (25%), length (20%), sentiment (15%)
    overall = int(
        keyword_result["score"] * 0.40 +
        technical_score         * 0.25 +
        length_result["score"]  * 0.20 +
        sentiment_score         * 0.15
    )

    suggestions = generate_suggestions(
        keyword_result, length_result, sentiment_score, technical_score
    )

    return {
        "overall_score":    overall,
        "keyword_score":    keyword_result["score"],
        "sentiment_score":  sentiment_score,
        "length_score":     length_result["score"],
        "technical_score":  technical_score,
        "missing_keywords": keyword_result["missing"],
        "suggestions":      suggestions,
        "word_count":       length_result["word_count"]
    }
