"""
test_scorer.py  —  Run this to verify your NLP service works before wiring to Spring Boot.
Usage:  python test_scorer.py
"""

import scorer

# ── Test cases ────────────────────────────────────────────────────────────────
tests = [
    {
        "name": "Strong answer — Spring Boot auto-config",
        "answer": """
            Spring Boot auto-configuration works through @EnableAutoConfiguration,
            which is included in @SpringBootApplication. It reads configuration
            classes listed in spring.factories (or AutoConfiguration.imports in
            Spring Boot 3+). Each auto-config class uses conditional annotations
            like @ConditionalOnClass and @ConditionalOnMissingBean to decide
            whether to create specific beans. For example, if spring-boot-starter-data-jpa
            is on the classpath, DataSourceAutoConfiguration activates and creates
            a DataSource bean — but only if no user-defined DataSource bean exists.
            This allows developers to get started quickly without boilerplate config.
        """,
        "keywords": "@SpringBootApplication,@EnableAutoConfiguration,@ConditionalOnClass,spring.factories,@ConditionalOnMissingBean,AutoConfiguration.imports"
    },
    {
        "name": "Weak answer — vague, no keywords",
        "answer": "I think Spring Boot maybe automatically sets things up for you. Not sure exactly how it works but it's probably using some kind of configuration file.",
        "keywords": "@SpringBootApplication,@EnableAutoConfiguration,@ConditionalOnClass,spring.factories"
    },
    {
        "name": "Good Java OOP answer",
        "answer": """
            OOP in Java is built on four principles. Encapsulation means wrapping
            data and methods inside a class and hiding internal state using private
            fields with public getters/setters. Inheritance allows a subclass to
            extend a parent class using the extends keyword, reusing code.
            Polymorphism allows objects to be treated as their parent type —
            achieved through method overriding and interfaces. Abstraction hides
            implementation details using abstract classes or interfaces, exposing
            only what's necessary. For example, Animal is abstract, Dog extends it
            and overrides speak() — that's polymorphism and inheritance together.
        """,
        "keywords": "encapsulation,inheritance,polymorphism,abstraction,interface,abstract,extends,override"
    },
    {
        "name": "Empty answer",
        "answer": "",
        "keywords": "java,spring"
    }
]

# ── Run tests ─────────────────────────────────────────────────────────────────
print("=" * 65)
print("PrepIQ NLP Scorer — Test Results")
print("=" * 65)

for t in tests:
    print(f"\n📝 {t['name']}")
    print("-" * 55)
    result = scorer.analyze(t["answer"].strip(), t["keywords"])
    print(f"  Overall score   : {result['overall_score']}/100")
    print(f"  Keyword score   : {result['keyword_score']}/100")
    print(f"  Sentiment score : {result['sentiment_score']}/100")
    print(f"  Length score    : {result['length_score']}/100  ({result['word_count']} words)")
    print(f"  Technical score : {result['technical_score']}/100")
    if result["missing_keywords"]:
        print(f"  Missing kw      : {', '.join(result['missing_keywords'][:4])}")
    print(f"  Suggestion      : {result['suggestions'][:90]}...")

print("\n" + "=" * 65)
print("All tests done. If scores look sensible, your NLP service is ready.")
print("=" * 65)
